package com.touchpilot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.View

// Brand colours shared by the app screen, the floating panel and the point editor.
object Brand {
    const val GREEN = 0xFF13B27E.toInt()
    const val TEAL = 0xFF0B6A8C.toInt()
    const val MINT = 0xFF7FE3BC.toInt()
    const val INK = 0xFF0E1A27.toInt()
    const val CARD = 0xFF152536.toInt()
    const val TILE = 0xFF1E3347.toInt()
    const val MUTED = 0xFF8FA6BC.toInt()
    const val WARN = 0xFFFFB74D.toInt()
    const val DANGER = 0xFFC62828.toInt()
}

// The round "حياة" logo: green-to-teal disc, white ring and the word mark (res/drawable/hayat_logo_fg).
// In stop mode (fast-repeat running) it turns red with a stop square so one tap on it stops the repeat.
class HayatLogoView(context: Context, private val sizeDp: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mark = context.getDrawable(R.drawable.hayat_logo_fg)
    private val density = context.resources.displayMetrics.density

    var stopMode: Boolean = false
        set(value) { field = value; invalidate() }

    private fun px(v: Float) = v * density

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = px(sizeDp.toFloat()).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val ring = px(2f)
        val r = width / 2f - ring
        paint.style = Paint.Style.FILL
        if (stopMode) {
            paint.shader = null
            paint.color = Brand.DANGER
        } else {
            paint.shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), Brand.GREEN, Brand.TEAL, Shader.TileMode.CLAMP)
        }
        canvas.drawCircle(cx, cy, r, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = ring
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, r, paint)
        if (stopMode) {
            paint.style = Paint.Style.FILL
            val s = r * 0.42f
            canvas.drawRoundRect(cx - s, cy - s, cx + s, cy + s, px(3f), px(3f), paint)
        } else {
            // The drawable has a safe-zone margin (it is an adaptive-icon foreground), so draw it larger than the disc.
            val size = (width * 1.45f).toInt()
            val offset = (width - size) / 2
            mark?.setBounds(offset, offset, offset + size, offset + size)
            mark?.draw(canvas)
        }
    }
}
